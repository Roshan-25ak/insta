import random

captions = [
    "💪 Hustle in silence, let success make the noise.",
    "🔥 One day, or day one. You decide.",
    "🌟 Small steps every day = big results.",
    "🎯 Your only limit is your mind."
]

def get_caption():
    return random.choice(captions)