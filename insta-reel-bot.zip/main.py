from scheduler import start_schedule

if __name__ == "__main__":
    start_schedule()