# Insta Reel Bot

An automated Instagram reel posting bot with text overlays using AI captions. Runs on Render or locally.